package com.clk.team4.catculator

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
